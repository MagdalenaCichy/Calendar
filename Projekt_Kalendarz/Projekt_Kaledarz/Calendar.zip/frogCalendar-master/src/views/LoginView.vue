<script setup lang="ts">
import Login from "@/components/login/Login.vue";
</script>

<template>
  <div id="rectangle1"></div>
  <div id="rectangle2"></div>

  <p class="login-acc-text">Zaloguj się</p>

  <div id="login-container">
    <Login />
  </div>
</template>

<style scoped src="@/assets/css/loginView.css"></style>
