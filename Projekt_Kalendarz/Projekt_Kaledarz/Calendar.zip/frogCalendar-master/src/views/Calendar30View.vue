<script setup lang="ts">
import CalendarMonth from "@/components/Calendar/CalendarMonth.vue";
</script>

<template>
  <div class="app-views-container">
    <CalendarMonth/>
  </div>
</template>

<style scoped src="@/assets/css/projectView.css"></style>
