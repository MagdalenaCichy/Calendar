<script setup lang="ts">
import Register from "@/components/login/Register.vue";
</script>

<template>
  <div id="rectangle1"></div>
  <div id="rectangle2"></div>

  <p class="create-acc-text">Utwórz konto</p>

  <div id="register-container">
    <Register />
  </div>
</template>

<style scoped src="@/assets/css/registerView.css"></style>
