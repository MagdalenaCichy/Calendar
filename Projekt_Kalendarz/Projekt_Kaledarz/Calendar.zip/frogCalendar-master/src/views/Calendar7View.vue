<script setup lang="ts">
import CalendarWeek from "@/components/Calendar/CalendarWeek.vue";
</script>

<template>
  <div class="app-views-container">
    <CalendarWeek/>
  </div>
</template>

<style scoped src="@/assets/css/projectView.css"></style>
