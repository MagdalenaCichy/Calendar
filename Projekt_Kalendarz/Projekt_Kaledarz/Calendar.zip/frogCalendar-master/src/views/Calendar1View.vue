<script setup lang="ts">
import CalendarDay from "@/components/Calendar/CalendarDay.vue";
</script>

<template>
  <div class="app-views-container">
    <CalendarDay />
  </div>
</template>

<style scoped src="@/assets/css/projectView.css"></style>
